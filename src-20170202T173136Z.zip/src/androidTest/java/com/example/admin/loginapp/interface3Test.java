package com.example.admin.loginapp;

import junit.framework.TestCase;

/**
 * Created by Admin on 26-Mar-16.
 */
public class interface3Test extends TestCase {


}